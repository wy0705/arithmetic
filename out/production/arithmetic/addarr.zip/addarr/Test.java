package addarr;

public class Test {
    public static void main(String[] args) {
        Addarr addarr=new Addarr();
        addarr.addarr();
    }
}
